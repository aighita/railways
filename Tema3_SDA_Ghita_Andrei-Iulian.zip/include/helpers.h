/**
 *  Ghita Andrei-Iulian 324CB
*/
#include <stdio.h>

#ifndef _FUNCTIONS_H_
#define _FUNCTIONS_H_

void reset_output_file();
FILE *open_file_in();
FILE *open_file_out();
float float_max(float a, float b);
int int_max(int a, int b);

#endif